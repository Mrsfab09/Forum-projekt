<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/footer.css">
</head>
<body>
    <footer class="footer">
        <div class="socialIcons">
            <a href="https://github.com/Mrsfab09">
                <i class="ri-github-fill"></i>
            </a>
            <p class="footerBottom">© Forum Informatyka Wszelkie prawa zastrzeżone 2023</p>
        </div>
    </footer>
</body>
</html>