<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="popup2" id="popup">
        <img src="img/good-icon.png" alt="good">
        <h2>Udało się</h2>
        <p>Twoje dane zostały pomyślnie przesłane</p>
        <button class="good" type="button" onclick="closePopup()">OK</button>
    </div>
</body>
</html>