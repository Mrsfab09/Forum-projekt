<!-- <?php
    session_start();

    if (!isset($_SESSION['user_id'])) {
        // Użytkownik nie jest zalogowany, przekierowanie na stronę logowania
        header("location: question.php");
        exit;
    }
?> -->