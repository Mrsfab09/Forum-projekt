function toggleEdit() {
    var editableContent = document.getElementById("editableContent");
    editableContent.classList.toggle("hidden");
  }